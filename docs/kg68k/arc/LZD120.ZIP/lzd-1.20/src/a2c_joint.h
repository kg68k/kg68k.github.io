/******************************************************************************
 *		�A�Z���u���^�b�����p�w�b�_
 *
 *		Copyright 1991,92,93,94 KIYO
 *
 ******************************************************************************/

#ifndef A2C_JOINT_H
#define A2C_JOINT_H

#include <sys/types.h>

u_int	compress_block (char *, char *, u_int, char *);
u_int	extract_block (char *, char *);

#endif
