/* $Id: version.c,v 2.76 1995/01/07 11:21:00 ryo Exp $
 *
 *	�\�[�X�R�[�h�W�F�l���[�^
 *	Version#
 *	Copyright (C) 1989,1990 K.Abe, 1994 R.ShimiZu
 *	All rights reserved.
 *	Copyright (C) 1997-2010 Tachibana
 *
 */

const char Version[] = "3.16";
const char Date[] = "2010-05-25";

#ifdef	OSKDIS
const char OSKEdition = " edition ?";
#endif

/* EOF */
